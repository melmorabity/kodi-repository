Arte video plugin for Kodi
==========================

This add-on provides access to the [Arte](https://www.arte.tv/) live and catchup TV platform.

Dependencies
------------

* Kodi 19 or higher
* script.module.dateutil
* script.module.inputstreamhelper
* script.module.requests

Disclaimer
----------

This add-on is neither officially commisioned nor supported by Arte. Any trademarks used belong to their respective owners.

License
-------

This add-on is licensed under the GNU General Public License version 2 or later.

Some icons come from, or are based on, the [Bootstrap](https://icons.getbootstrap.com/) project and are licensed under [MIT](https://github.com/twbs/icons/blob/main/LICENSE.md).
